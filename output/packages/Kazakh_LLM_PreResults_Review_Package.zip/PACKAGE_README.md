# Kazakh LLM Error Study — Pre-results Review Package

Built on 16 November 2026. This archive is for instructor/process review. It is
not a result-bearing journal submission and not the `final` reproducibility
release.

## Verified current state

- 240/240 test receipts are immutable and pass request-accounting validation.
- The four exact model configurations and study Mac environment are recorded.
- The blinded team-gold workbook still contains empty human-review fields.
- Final statistics, ranking, result figures and result-bearing claims do not yet
  exist.
- `release_gate.py` returns `ready: false` by design.

## Contents

- `deliverables/Kazakh_LLM_Study_Manuscript.docx`
- `deliverables/Kazakh_LLM_Study_ACM_Submission.docx`
- `deliverables/Cover_Letter_TALLIP.docx` — controlled draft, not for the editor
- `deliverables/Final_Submission_and_Defense_Guide_RU.docx`
- `output/pdf/Kazakh_LLM_Defense_Deck.pdf`
- `docs/FINAL_SUBMISSION_AND_DEFENSE_RU.md`
- `docs/CRITERIA_MATRIX.md`
- `docs/EXECUTION_STATUS.md`
- `docs/JOURNAL_FIT_STATEMENT.md`
- `docs/RELEASE_CHECKLIST.md`
- `docs/SUBMISSION_PACKAGE_RU.md`
- root `README.md`

Canonical repository:
https://github.com/qsheker/kazakh-llm-error-study

Do not create or advertise a `final` tag until all 240 human reviews, generated
analyses, numerical audit, institutional checks, author approvals and outside
reproduction are complete.
